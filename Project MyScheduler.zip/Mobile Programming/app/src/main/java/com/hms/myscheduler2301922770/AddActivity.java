package com.hms.myscheduler2301922770;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Locale;

public class AddActivity extends AppCompatActivity {

    EditText title;
    EditText description;
    Button date;
    Button time;
    Button insert;
    String dates;
    int hour, minute;
    String hours= String.valueOf(hour);
    String minutes= Integer.toString(minute);
    String times;
    DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        takeDate();

        title= findViewById(R.id.isiTitle);
        description= findViewById(R.id.isiDescription);
        date= findViewById(R.id.isiDate);
        date.setText(getTodaysDate());
        time= findViewById(R.id.isiTime);
        insert= findViewById(R.id.insert);



    }

    private String getTodaysDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }


    public void insert(View view){
        scheduleAtt sched= new scheduleAtt();
        sched.setTitle(title.getText().toString());
        sched.setDescription(description.getText().toString());
        sched.setDate(dates);
        sched.setTime(times);
        Home.scheduleList.add(sched);

        Intent insert_act = new Intent(this, Home.class);
        startActivity(insert_act);
    }

    public void takeTime(View view){
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hourOfDay, int minuteOfDay) {
                hour = hourOfDay;
                minute = minuteOfDay;
                time.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
                times= String.format("%02d:%02d", hour, minute);
            }
        };

        int style = AlertDialog.THEME_HOLO_DARK;

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, style, onTimeSetListener, hour, minute, true);

        timePickerDialog.setTitle("Select Time");
        timePickerDialog.show();

    }

    private void takeDate() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                dates = makeDateString(day, month, year);
                date.setText(dates);
            }
        };

        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
    }

    private String makeDateString(int day, int month, int year) {
        return getMonthFormat(month) + " " + day + " " + year;
    }

    private String getMonthFormat(int month) {
        if(month == 1)  return "JAN";
        if(month == 2)  return "FEB";
        if(month == 3)  return "MAR";
        if(month == 4)  return "APR";
        if(month == 5)  return "MAY";
        if(month == 6)  return "JUN";
        if(month == 7)  return "JUL";
        if(month == 8)  return "AUG";
        if(month == 9)  return "SEP";
        if(month == 10)  return "OCT";
        if(month == 11)  return "NOV";
        if(month == 2)  return "DES";

        return "JAN";

    }

    public void add(View view){
        Intent add_act = new Intent(this, AddActivity.class);
        startActivity(add_act);
    }

    public void all(View view){
        Intent all_schedules = new Intent(this, AllSchedules.class);
        startActivity(all_schedules);
    }

    public void home(View view) {
        Intent all_schedules = new Intent(this, Home.class);
        startActivity(all_schedules);
    }

    public void openDatePicker(View view){
        datePickerDialog.show();
    }


}
