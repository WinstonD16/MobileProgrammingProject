package com.hms.myscheduler2301922770;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Home extends AppCompatActivity {

    public static ArrayList<scheduleAtt> scheduleList= new ArrayList<>();
    TextView title;
    TextView date;
    TextView time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title= findViewById(R.id.title1);
        date= findViewById(R.id.date1);
        time= findViewById(R.id.time1);

        if(scheduleList.size()== 0){
            title.setText("No schedule found");
            date.setText("");
            time.setText("");
        }
        else {
            title.setText(scheduleList.get(0).getTitle());
            date.setText(scheduleList.get(0).getDate());
            time.setText(scheduleList.get(0).getTime());
        }



    }

    public void add(View view){
        Intent add_act = new Intent(this, AddActivity.class);
        startActivity(add_act);
    }

    public void all(View view){
        Intent all_schedules = new Intent(this, AllSchedules.class);
        startActivity(all_schedules);
    }

    public void home(View view) {
        Intent all_schedules = new Intent(this, Home.class);
        startActivity(all_schedules);
    }

}