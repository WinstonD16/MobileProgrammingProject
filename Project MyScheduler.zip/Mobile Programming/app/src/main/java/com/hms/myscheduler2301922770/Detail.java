package com.hms.myscheduler2301922770;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Detail extends AppCompatActivity {

    TextView title;
    TextView description;
    TextView time;
    TextView date;
    String schedTitle;
    String schedDesc;
    String schedTime;
    String schedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        title= findViewById(R.id.acaraDetail);
        date= findViewById(R.id.dateDetail);
        time= findViewById(R.id.timeDetail);
        description= findViewById(R.id.descriptionDetail);

        schedTitle= getIntent().getStringExtra("title");
        schedDesc= getIntent().getStringExtra("description");
        schedTime= getIntent().getStringExtra("time");
        schedDate= getIntent().getStringExtra("date");


        title.setText(schedTitle);
        date.setText(schedDate);
        time.setText(schedTime);
        description.setText(schedDesc);
    }

    public void add(View view){
        Intent add_act = new Intent(this, AddActivity.class);
        startActivity(add_act);
    }

    public void all(View view){
        Intent all_schedules = new Intent(this, AllSchedules.class);
        startActivity(all_schedules);
    }

    public void home(View view) {
        Intent all_schedules = new Intent(this, Home.class);
        startActivity(all_schedules);
    }
}