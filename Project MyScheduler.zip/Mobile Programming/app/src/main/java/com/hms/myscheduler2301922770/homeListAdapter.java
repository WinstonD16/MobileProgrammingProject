package com.hms.myscheduler2301922770;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class homeListAdapter extends RecyclerView.Adapter<homeListAdapter.viewHolder>{

    ArrayList<scheduleAtt> a_scheduleList;
    Context conSchedule;

    public homeListAdapter(Context conSchedule, ArrayList<scheduleAtt> a_scheduleList) {
        this.conSchedule= conSchedule;
        this.a_scheduleList= a_scheduleList;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(conSchedule).inflate(R.layout.activity_recycler, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull homeListAdapter.viewHolder holder, int position) {
        scheduleAtt schedule= a_scheduleList.get(position);
        holder.Title.setText(schedule.title);
        holder.Time.setText(schedule.time);
        holder.Date.setText(schedule.date);
        holder.Description.setText(schedule.description);
    }

    @Override
    public int getItemCount() {
        return a_scheduleList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView Title;
        TextView Time;
        TextView Date;
        TextView Description;

        public viewHolder(View view){
            super(view);
            Title= view.findViewById(R.id.recTitle);
            Time= view.findViewById(R.id.recTime);
            Date= view.findViewById(R.id.recDate);
            Description= view.findViewById(R.id.recDescription);
            itemView.setOnClickListener(this);
        }

        public void onClick(View v) {
            int pos= getAdapterPosition();
            scheduleAtt schedule= a_scheduleList.get(pos);
            Intent intent= new Intent(conSchedule, Detail.class);
            intent.putExtra("title", schedule.title);
            intent.putExtra("description", schedule.description);
            intent.putExtra("time", schedule.time);
            intent.putExtra("date", schedule.date);
            conSchedule.startActivity(intent);
        }
    }
}

