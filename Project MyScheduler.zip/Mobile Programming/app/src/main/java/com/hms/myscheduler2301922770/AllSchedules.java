package com.hms.myscheduler2301922770;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class AllSchedules extends AppCompatActivity {

    RecyclerView recyclerAll;
    homeListAdapter allAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_schedules);

        allAdapter= new homeListAdapter(this, Home.scheduleList);
        recyclerAll= findViewById(R.id.recyclerAllView);
        recyclerAll.setLayoutManager(new LinearLayoutManager(this));
        recyclerAll.setAdapter(allAdapter);
    }

    public void add(View view){
        Intent add_act = new Intent(this, AddActivity.class);
        startActivity(add_act);
    }

    public void all(View view){
        Intent all_schedules = new Intent(this, AllSchedules.class);
        startActivity(all_schedules);
    }

    public void home(View view) {
        Intent all_schedules = new Intent(this, Home.class);
        startActivity(all_schedules);
    }
}